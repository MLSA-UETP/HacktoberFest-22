/* NAV BAR */
let nav=document.querySelector(".navbar");
window.onscroll= function()
{
    if(document.documentElement.scrollTop > 20)
    {
        nav.classList.add("scrollon")    
    }
    else
    {
        nav.classList.remove("scrollon")
    }
}

/* Script for dropdown */
let navbar=document.querySelectorAll(".nav-link");
let navbar_collapse=document.querySelector(".collapse.navbar-collapse");
navbar.forEach(function(a)
{
    a.addEventListener("click",function()
    {
        navbar_collapse.classList.remove("show");
    })
})